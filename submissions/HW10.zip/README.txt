How to compile:
The makefile is supplied for compiling the program. A simple "make" should suffice.

How to run:
The hw10 file is a shell script specific for running the program for Assignment 10.

Time taken to complete the assignment:
Approximately 36 hours. Most of the work done on this assignment was spent learning OpenCL and passing the arguments to the kernel function for the program to run.

About this assignment:
This assignment compares the performance of SHA-1 hashing on the CPU and GPU. It performs 5000 hashes on the CPU and GPU alike and benchmarks the running time for the hashing function. The assignment splits the hashing into several local and global workgroups where each workgroup computes a couple hashes at once.

Results:
On my macbook pro, since it does not have a graphics card it takes approximately 8 ms to compute the hashes on the "GPU" and 0 ms to compute the hashes on the CPU.

On the CSEL graphics machine since it does have a dedicated graphics card, it takes approximately 0 ms (less than 1000000 ns) to compute 5000 hashes on the CPU and 22 ms to compute 5000 hashes on the CPU.
