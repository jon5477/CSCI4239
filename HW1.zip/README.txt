Hotkeys:
0 - reset the view angle
A/a - toggle axes
P/p - change viewing mode (orthogonal/perspective)
O/o - change objects
M/m - change shaders
Arrow keys - Change the viewing angle
Page Up/Down - Change the dimensional viewing for orthonal or perspective mode

How to compile:
The makefile is supplied for compiling the program. A simple "make" should suffice.

How to run:
The hw1 file is a shell script specific for running the program for Assignment 1.

Time taken to complete the assignment:
Approximately 24 hours. I had to write my own specific libraries for parsing the OBJs.