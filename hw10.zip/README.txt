How to compile:
The makefile is supplied for compiling the program. A simple "make" should suffice.

How to run:
The hw10 file is a shell script specific for running the program for Assignment 10.

Time taken to complete the assignment:
Approximately 6 hours. Most of the work done on this assignment was spent learning
OpenCL and passing the arguments to the kernel function for the program to run.